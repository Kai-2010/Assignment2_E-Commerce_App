﻿namespace Assignment2test1
{
    partial class NutritionInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            txtb4 = new TextBox();
            label7 = new Label();
            txtb3 = new TextBox();
            label6 = new Label();
            btn_CalBMI = new Button();
            txtb2 = new TextBox();
            label3 = new Label();
            txtb1 = new TextBox();
            label2 = new Label();
            groupBox2 = new GroupBox();
            dgv1 = new DataGridView();
            btn_RecordCaloric = new Button();
            txtb6 = new TextBox();
            txtb5 = new TextBox();
            label8 = new Label();
            label9 = new Label();
            groupBox3 = new GroupBox();
            dgv2 = new DataGridView();
            label4 = new Label();
            cbb = new ComboBox();
            btn_RecordExercise = new Button();
            txtb9 = new TextBox();
            txtb8 = new TextBox();
            label12 = new Label();
            label11 = new Label();
            txtb7 = new TextBox();
            label10 = new Label();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv1).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 19);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 1;
            label1.Text = "label1";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtb4);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(txtb3);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(btn_CalBMI);
            groupBox1.Controls.Add(txtb2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtb1);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(22, 54);
            groupBox1.Margin = new Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2);
            groupBox1.Size = new Size(275, 227);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "BMI Calc";
            // 
            // txtb4
            // 
            txtb4.Location = new Point(123, 147);
            txtb4.Margin = new Padding(2);
            txtb4.Name = "txtb4";
            txtb4.ReadOnly = true;
            txtb4.Size = new Size(141, 23);
            txtb4.TabIndex = 18;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(17, 150);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(69, 15);
            label7.TabIndex = 17;
            label7.Text = "Suggestion:";
            // 
            // txtb3
            // 
            txtb3.Location = new Point(123, 109);
            txtb3.Margin = new Padding(2);
            txtb3.Name = "txtb3";
            txtb3.ReadOnly = true;
            txtb3.Size = new Size(141, 23);
            txtb3.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(17, 112);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(31, 15);
            label6.TabIndex = 15;
            label6.Text = "BMI:";
            // 
            // btn_CalBMI
            // 
            btn_CalBMI.Location = new Point(20, 191);
            btn_CalBMI.Margin = new Padding(2);
            btn_CalBMI.Name = "btn_CalBMI";
            btn_CalBMI.Size = new Size(242, 21);
            btn_CalBMI.TabIndex = 14;
            btn_CalBMI.Text = "Cal BMI";
            btn_CalBMI.UseVisualStyleBackColor = true;
            btn_CalBMI.Click += btn_CalBMI_Click;
            // 
            // txtb2
            // 
            txtb2.Location = new Point(123, 73);
            txtb2.Margin = new Padding(2);
            txtb2.Name = "txtb2";
            txtb2.Size = new Size(141, 23);
            txtb2.TabIndex = 11;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(15, 73);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(99, 15);
            label3.TabIndex = 10;
            label3.Text = "Latest Height(m):";
            // 
            // txtb1
            // 
            txtb1.Location = new Point(123, 35);
            txtb1.Margin = new Padding(2);
            txtb1.Name = "txtb1";
            txtb1.ReadOnly = true;
            txtb1.Size = new Size(141, 23);
            txtb1.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 36);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(103, 15);
            label2.TabIndex = 4;
            label2.Text = "Latest Weight(kg):";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(dgv1);
            groupBox2.Controls.Add(btn_RecordCaloric);
            groupBox2.Controls.Add(txtb6);
            groupBox2.Controls.Add(txtb5);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label9);
            groupBox2.Location = new Point(22, 299);
            groupBox2.Margin = new Padding(2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(2);
            groupBox2.Size = new Size(275, 326);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Caloric Intake";
            // 
            // dgv1
            // 
            dgv1.AllowUserToAddRows = false;
            dgv1.AllowUserToDeleteRows = false;
            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv1.Location = new Point(20, 140);
            dgv1.Margin = new Padding(2);
            dgv1.Name = "dgv1";
            dgv1.ReadOnly = true;
            dgv1.RowHeadersWidth = 72;
            dgv1.RowTemplate.Height = 36;
            dgv1.Size = new Size(242, 171);
            dgv1.TabIndex = 15;
            // 
            // btn_RecordCaloric
            // 
            btn_RecordCaloric.Location = new Point(20, 100);
            btn_RecordCaloric.Margin = new Padding(2);
            btn_RecordCaloric.Name = "btn_RecordCaloric";
            btn_RecordCaloric.Size = new Size(242, 21);
            btn_RecordCaloric.TabIndex = 14;
            btn_RecordCaloric.Text = "Record Caloric\r\n";
            btn_RecordCaloric.UseVisualStyleBackColor = true;
            btn_RecordCaloric.Click += btn_RecordCaloric_Click;
            // 
            // txtb6
            // 
            txtb6.Location = new Point(123, 65);
            txtb6.Margin = new Padding(2);
            txtb6.Name = "txtb6";
            txtb6.Size = new Size(141, 23);
            txtb6.TabIndex = 13;
            // 
            // txtb5
            // 
            txtb5.Location = new Point(123, 30);
            txtb5.Margin = new Padding(2);
            txtb5.Name = "txtb5";
            txtb5.ReadOnly = true;
            txtb5.Size = new Size(141, 23);
            txtb5.TabIndex = 11;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(20, 68);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(50, 15);
            label8.TabIndex = 10;
            label8.Text = "Caloric :";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(20, 30);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(77, 15);
            label9.TabIndex = 12;
            label9.Text = "Current Date:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(dgv2);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(cbb);
            groupBox3.Controls.Add(btn_RecordExercise);
            groupBox3.Controls.Add(txtb9);
            groupBox3.Controls.Add(txtb8);
            groupBox3.Controls.Add(label12);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(txtb7);
            groupBox3.Controls.Add(label10);
            groupBox3.Location = new Point(316, 54);
            groupBox3.Margin = new Padding(2);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(2);
            groupBox3.Size = new Size(312, 571);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "Movement Goal";
            // 
            // dgv2
            // 
            dgv2.AllowUserToAddRows = false;
            dgv2.AllowUserToDeleteRows = false;
            dgv2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv2.Location = new Point(13, 386);
            dgv2.Margin = new Padding(2);
            dgv2.Name = "dgv2";
            dgv2.ReadOnly = true;
            dgv2.RowHeadersWidth = 72;
            dgv2.RowTemplate.Height = 36;
            dgv2.Size = new Size(288, 171);
            dgv2.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 349);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(74, 15);
            label4.TabIndex = 22;
            label4.Text = "Record Date:";
            // 
            // cbb
            // 
            cbb.DropDownStyle = ComboBoxStyle.DropDownList;
            cbb.FormattingEnabled = true;
            cbb.Location = new Point(158, 348);
            cbb.Margin = new Padding(2);
            cbb.Name = "cbb";
            cbb.Size = new Size(145, 23);
            cbb.TabIndex = 21;
            cbb.SelectedIndexChanged += cbb_SelectedIndexChanged;
            // 
            // btn_RecordExercise
            // 
            btn_RecordExercise.Location = new Point(13, 191);
            btn_RecordExercise.Margin = new Padding(2);
            btn_RecordExercise.Name = "btn_RecordExercise";
            btn_RecordExercise.Size = new Size(288, 21);
            btn_RecordExercise.TabIndex = 19;
            btn_RecordExercise.Text = "Record Exercise";
            btn_RecordExercise.UseVisualStyleBackColor = true;
            btn_RecordExercise.Click += btn_RecordExercise_Click;
            // 
            // txtb9
            // 
            txtb9.Location = new Point(158, 108);
            txtb9.Margin = new Padding(2);
            txtb9.Name = "txtb9";
            txtb9.Size = new Size(145, 23);
            txtb9.TabIndex = 20;
            // 
            // txtb8
            // 
            txtb8.Location = new Point(158, 71);
            txtb8.Margin = new Padding(2);
            txtb8.Name = "txtb8";
            txtb8.Size = new Size(145, 23);
            txtb8.TabIndex = 19;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(13, 109);
            label12.Margin = new Padding(2, 0, 2, 0);
            label12.Name = "label12";
            label12.Size = new Size(130, 15);
            label12.TabIndex = 16;
            label12.Text = "Exercise Duration(min):";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(13, 74);
            label11.Margin = new Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new Size(79, 15);
            label11.TabIndex = 15;
            label11.Text = "Exercise Type:";
            // 
            // txtb7
            // 
            txtb7.Location = new Point(158, 36);
            txtb7.Margin = new Padding(2);
            txtb7.Name = "txtb7";
            txtb7.ReadOnly = true;
            txtb7.Size = new Size(145, 23);
            txtb7.TabIndex = 13;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(13, 36);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(77, 15);
            label10.TabIndex = 14;
            label10.Text = "Current Date:";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.pic3;
            pictureBox1.Location = new Point(648, 61);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(566, 564);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // NutritionInformation
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1216, 628);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Margin = new Padding(2);
            Name = "NutritionInformation";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NutritionInformation";
            Load += NutritionInformation_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv1).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private Label label2;
        private TextBox txtb1;
        private TextBox txtb2;
        private Label label3;
        private Button btn_CalBMI;
        private TextBox txtb4;
        private Label label7;
        private TextBox txtb3;
        private Label label6;
        private GroupBox groupBox2;
        private TextBox txtb6;
        private TextBox txtb5;
        private Label label8;
        private Label label9;
        private Button btn_RecordCaloric;
        private DataGridView dgv1;
        private GroupBox groupBox3;
        private TextBox txtb7;
        private Label label10;
        private Label label11;
        private TextBox txtb9;
        private TextBox txtb8;
        private Label label12;
        private Button btn_RecordExercise;
        private ComboBox cbb;
        private Label label4;
        private DataGridView dgv2;
        private PictureBox pictureBox1;
    }
}