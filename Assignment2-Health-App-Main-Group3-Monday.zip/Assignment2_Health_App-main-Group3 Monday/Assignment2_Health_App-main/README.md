# Assignment2_Health_App
## HealthDB data entries
| CustomerID | FirstName | LastName | Address | Email | PhoneNumber | Password | Sex | HeartAttack | Diabetes | ChronicDisease | Other |
|------------|-----------|----------|---------|-------|-------------|----------|-----|-------------|----------|----------------|-------|
| 0	| Peter	| Pan	  | 12 Main Street | peter.pan@hotmail.com	| 0490564321 | Password123 | M | 1 | 1 | 1 | 1 |
| 1	| Tammy	| Tammy	| 12 A Street    | tammy@tammy.com	      |	0456789010 | 123456	     | F | 0 | 0 | 0 | 0 |
| 2	| uyug	| ygug	| 12 wat		     | yy@yy.com		          | 0424936302 | 1234567aA*	 | P | 0 | 1 | 0 | 0 |
| 3	| test	| test	| 12 Tea Street	 | test.test@gmail.com	  | 0490765432 | 1234567Aa@	 | F | 0 | 0 | 0 | 0 |
| 4	| ghjgb	| ghhk	| 12 wat		     | bb@bb.com		          | 0424936302 | 1234567aA#	 | M | 0 | 0 | 0 | 0 |
| 5	| gg	  | gg	  | 111		         | rr@ff.com		          | 0435465734 | 1234567sS@	 | M | 0 | 0 | 0 | 0 |
| 6	| tttt	| ttttt	| 12 Main Street | t@t.com			          | 0490876543 | 1234567Aa@	 | F | 1 | 0 | 0 | 0 |
| 7	| lat	  | tal	  | 12 runner	     | lat.tal@tal.com		    | 0448349524 | 1234567aA@	 | M | 0 | 0 | 0 | 1 |
| 8	| aaaa	| aaaa	| 12 Wat		     | aaa@aaa.com		        | 0490373534 | 1234567Aa@	 | F | 0 | 0 | 0 | 0 |
| 9	| Dude	| Dude	| address		     | dude@mail.com		      | 0412312312 |Password123	 | M | 0 | 1 | 0 | 1 |
